<?php
/**
 * Template per i contenuti protetti da OTP.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();

$plugin  = OTP_Access_Manager_Plugin::instance();
$post_id = get_the_ID();
$has_access = $plugin->visitor_has_access( $post_id );

ob_start();
$plugin->render_status_notice( $post_id );
$status_notice = ob_get_clean();

?>
<div class="otp-access-wrapper">
    <div class="otp-access-container <?php echo $has_access ? 'otp-access-unlocked' : 'otp-access-locked'; ?>">
        <header class="otp-access-header">
            <h1 class="otp-access-title"><?php the_title(); ?></h1>
        </header>

        <?php if ( $has_access ) : ?>
            <?php if ( $status_notice ) : ?>
                <?php echo wp_kses_post( $status_notice ); ?>
            <?php endif; ?>

            <div class="otp-access-content">
                <?php
                while ( have_posts() ) {
                    the_post();
                    the_content();
                }
                ?>
            </div>
        <?php else : ?>
            <div class="otp-access-overlay" role="dialog" aria-modal="true">
                <div class="otp-access-modal">
                    <h4 class="otp-access-modal-title"><?php echo esc_html( $plugin->get_option( OTP_Access_Manager_Plugin::OPTION_MODAL_TITLE ) ); ?></h4>
                    <?php
                    $allowed_users = (array) get_post_meta( $post_id, OTP_Access_Manager_Plugin::META_ALLOWED_USERS, true );
                    if ( empty( $allowed_users ) ) :
                    ?>
                        <p class="otp-access-modal-lead"><?php echo esc_html( $plugin->get_option( OTP_Access_Manager_Plugin::OPTION_BLOCKED_MESSAGE ) ); ?></p>
                    <?php else : ?>
                        <?php
                        $context = $plugin->get_view_context( $post_id );
                        if ( ! in_array( $context['status'], [ 'code_sent', 'invalid_code' ], true ) ) {
                            $require_first_name = $plugin->get_option( OTP_Access_Manager_Plugin::OPTION_REQUIRE_FIRST_NAME );
                            $require_last_name = $plugin->get_option( OTP_Access_Manager_Plugin::OPTION_REQUIRE_LAST_NAME );
                            
                            if ( $require_first_name && $require_last_name ) {
                                $message = esc_html__( 'Inserisci nome, cognome e numero di telefono per ricevere il codice di accesso.', 'otp-in' );
                            } elseif ( $require_first_name ) {
                                $message = esc_html__( 'Inserisci nome e numero di telefono per ricevere il codice di accesso.', 'otp-in' );
                            } elseif ( $require_last_name ) {
                                $message = esc_html__( 'Inserisci cognome e numero di telefono per ricevere il codice di accesso.', 'otp-in' );
                            } else {
                                $message = esc_html__( 'Inserisci numero di telefono per ricevere il codice di accesso.', 'otp-in' );
                            }
                            echo '<p class="otp-access-modal-lead">' . esc_html( $message ) . '</p>';
                        }
                        echo wp_kses_post( $status_notice );
                        ?>
                        <div class="otp-access-forms">
                            <?php
                            if ( in_array( $context['status'], [ 'code_sent', 'invalid_code' ], true ) ) {
                                $plugin->render_verify_form( $post_id );
                            } else {
                                $plugin->render_request_form( $post_id );
                            }
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.otp-access-wrapper {
    margin: 0 auto;
}
.otp-access-container {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 32px;
    box-shadow: 0 15px 35px -15px rgba(15, 23, 42, 0.25);
    position: relative;
    overflow: hidden;
}
.otp-access-container.otp-access-locked {
    min-height: 420px;
}
.otp-access-overlay {
    position: fixed;
    inset: 0;
    background: #f1f5f9;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 32px 20px;
    z-index: 10;
}
.otp-access-modal {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 25px 60px -25px rgba(15, 23, 42, 0.55);
    width: 100%;
    max-width: 400px;
    padding: 32px;
}
.otp-access-modal-title {
    margin: 0 0 8px;
}
.otp-access-modal-lead {
    margin: 0 0 20px;
    color: #4b5563;
}
.otp-access-header {
    margin-bottom: 24px;
    border-bottom: 1px solid #f1f5f9;
    padding-bottom: 16px;
}
.otp-access-title {
    margin: 0;
}
.otp-access-form {
    margin: 0;
}
.otp-access-form button {
    font-weight: 600;
    font-size: inherit;
    width: 100%;
    padding: 10px 14px;
    margin-top: 16px;
    box-sizing: border-box;
    border: 1px solid #cbd5f5;
    border-radius: 4px;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
.otp-access-field {
    margin-bottom: 8px;
}
.otp-access-field label {
    display: block;
    font-size: medium;
    font-weight: 600;
    color: #1f2937;
}
.otp-access-field input, 
.otp-access-field select {
    width: 100%;
    padding: 10px 14px;
    box-sizing: border-box;
    font-size: larger;
    border: 1px solid #cbd5f5;
    border-radius: 4px;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
.otp-access-field input:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
    outline: none;
}
.otp-access-field select {
    width: 38% !important;
    letter-spacing: -1px;
    padding-left: 10px;
}
.otp-access-helper {
    margin: 0 0 12px;
    color: #4b5563;
}
.otp-access-notice {
    margin: 0 0 20px;
    padding: 12px 16px;
    border-radius: 4px;
}
.otp-access-code_sent {
    background: #ecfdf5;
    border: 1px solid #34d399;
    color: #065f46;
}
.otp-access-invalid_code,
.otp-access-user_not_allowed,
.otp-access-access_expired,
.otp-access-access_disabled {
    background: #fef2f2;
    border: 1px solid #f87171;
    color: #991b1b;
}
.otp-access-access_granted {
    background: #eff6ff;
    border: 1px solid #3b82f6;
    color: #1d4ed8;
}


@media (max-width: 600px) {
    .otp-access-container {
        padding: 24px;
    }
    .otp-access-modal {
        padding: 24px;
    }
}
</style>

<?php
get_footer();
