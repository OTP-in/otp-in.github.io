<?php
/**
 * Core plugin class for OTP Access Manager.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class OTP_Access_Manager_Plugin {

    const POST_TYPE_USER = 'otp_secure_user';
    const META_ALLOWED_USERS = '_otp_access_allowed_users';
    const META_ENABLED       = '_otp_access_enabled';
    const META_FIRST_NAME   = '_otp_access_first_name';
    const META_LAST_NAME    = '_otp_access_last_name';
    const META_EMAIL        = '_otp_access_email';
    const META_PHONE        = '_otp_access_phone';
    const META_COUNTRY_CODE = '_otp_access_country_code';
    const META_ACCESS_DURATION = '_otp_access_duration';
    const META_EXPIRY_DATE = '_otp_access_expiry_date';
    const META_EXPIRY_TIME = '_otp_access_expiry_time';
    const META_USER_ACTIVE = '_otp_access_user_active';
    const OTP_TRANSIENT_PREFIX   = 'otp_access_code_';
    const TOKEN_TRANSIENT_PREFIX = 'otp_access_token_';
    const COOKIE_PREFIX = 'otp_access_';
    const OPTION_BLOCKED_MESSAGE = 'otp_access_blocked_message';
    const OPTION_MODAL_TITLE = 'otp_access_modal_title';
    const OPTION_REQUIRE_LAST_NAME = 'otp_access_require_last_name';
    const OPTION_REQUIRE_FIRST_NAME = 'otp_access_require_first_name';
    const OPTION_OVERLAY_COLOR = 'otp_access_overlay_color';
    const OPTION_OVERLAY_OPACITY = 'otp_access_overlay_opacity';
    const OPTION_MODAL_BG_COLOR = 'otp_access_modal_bg_color';
    const OPTION_MODAL_TEXT_COLOR = 'otp_access_modal_text_color';
    const OPTION_MODAL_SHADOW = 'otp_access_modal_shadow';

    /**
     * Singleton instance.
     *
     * @var self
     */
    protected static $instance = null;

    /**
     * Cached state for template rendering.
     *
     * @var array
     */
    protected $view_context = [];

    /**
     * Get singleton instance.
     *
     * @return self
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     */
    protected function __construct() {
        add_action( 'init', [ $this, 'load_textdomain' ] );
        add_action( 'init', [ $this, 'register_post_types' ] );
        add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );
        add_action( 'add_meta_boxes', [ $this, 'register_meta_boxes' ] );
        add_action( 'save_post_' . self::POST_TYPE_USER, [ $this, 'save_user_meta' ], 10, 2 );
        add_action( 'manage_' . self::POST_TYPE_USER . '_posts_columns', [ $this, 'columns_for_users' ] );
        add_action( 'manage_' . self::POST_TYPE_USER . '_posts_custom_column', [ $this, 'render_user_columns' ], 10, 2 );
        add_action( 'save_post', [ $this, 'save_content_meta' ], 10, 2 );
        add_filter( 'manage_post_posts_columns', [ $this, 'add_content_columns' ] );
        add_filter( 'manage_page_posts_columns', [ $this, 'add_content_columns' ] );
        add_action( 'manage_post_posts_custom_column', [ $this, 'render_content_columns' ], 10, 2 );
        add_action( 'manage_page_posts_custom_column', [ $this, 'render_content_columns' ], 10, 2 );
        add_filter( 'manage_edit-' . self::POST_TYPE_USER . '_sortable_columns', [ $this, 'sortable_user_columns' ] );
        add_action( 'pre_get_posts', [ $this, 'handle_user_sorting' ] );
        add_filter( 'enter_title_here', [ $this, 'filter_enter_title_here' ], 10, 2 );
        add_filter( 'single_template', [ $this, 'filter_single_template' ] );
        add_filter( 'page_template', [ $this, 'filter_single_template' ] );
        add_action( 'template_redirect', [ $this, 'handle_frontend_submission' ] );
        add_action( 'init', [ $this, 'register_shortcodes' ] );
        add_action( 'wp_head', [ $this, 'output_custom_modal_styles' ] );
        add_filter( 'default_title', [ $this, 'set_default_user_title' ], 10, 2 );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
    }

    /**
     * Load plugin textdomain.
     */
    public function load_textdomain() {
        // phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- Required for local plugin translations.
        load_plugin_textdomain( 'otp-in', false, basename( OTP_ACCESS_MANAGER_PATH ) . '/languages' );
    }

    /**
     * Register custom post types.
     */
    public function register_post_types() {
        $user_labels = [
            'name'               => __( 'Utenti OTP', 'otp-in' ),
            'singular_name'      => __( 'Utente OTP', 'otp-in' ),
            'add_new'            => __( 'Aggiungi Utente', 'otp-in' ),
            'add_new_item'       => __( 'Aggiungi nuovo utente', 'otp-in' ),
            'edit_item'          => __( 'Modifica utente', 'otp-in' ),
            'new_item'           => __( 'Nuovo utente', 'otp-in' ),
            'view_item'          => __( 'Visualizza utente', 'otp-in' ),
            'search_items'       => __( 'Cerca utenti', 'otp-in' ),
            'not_found'          => __( 'Nessun utente trovato', 'otp-in' ),
            'not_found_in_trash' => __( 'Nessun utente nel cestino', 'otp-in' ),
            'all_items'          => __( 'Tutti gli utenti', 'otp-in' ),
        ];

        $user_args = [
            'label'               => __( 'Utenti OTP', 'otp-in' ),
            'labels'              => $user_labels,
            'public'              => false,
            'show_ui'             => true,
            'show_in_menu'        => 'otp-in',
            'supports'            => [ 'title' ],
            'capability_type'     => 'post',
            'map_meta_cap'        => true,
            'menu_position'       => 6,
        ];

        register_post_type( self::POST_TYPE_USER, $user_args );
    }

    /**
     * Register top-level admin menu.
     */
    public function register_admin_menu() {
        add_menu_page(
            __( 'OTP in', 'otp-in' ),
            __( 'OTP in', 'otp-in' ),
            'edit_posts',
            'otp-in',
            [ $this, 'render_admin_overview' ],
            'dashicons-shield-alt',
            26
        );
        
        add_submenu_page(
            'otp-in',
            __( 'Aggiungi utente', 'otp-in' ),
            __( 'Aggiungi utente', 'otp-in' ),
            'edit_posts',
            'post-new.php?post_type=' . self::POST_TYPE_USER
        );
        
        add_submenu_page(
            'otp-in',
            __( 'Pagine attive', 'otp-in' ),
            __( 'Pagine attive', 'otp-in' ),
            'edit_posts',
            'otp-access-active-pages',
            [ $this, 'render_active_pages' ]
        );
        
        add_submenu_page(
            'otp-in',
            __( 'Opzioni', 'otp-in' ),
            __( 'Opzioni', 'otp-in' ),
            'manage_options',
            'otp-access-options',
            [ $this, 'render_options_page' ]
        );
    }

    /**
     * Render admin overview page.
     */
    public function render_admin_overview() {
        echo '<div class="wrap">';
        echo '<h1>' . esc_html__( 'OTP in', 'otp-in' ) . '</h1>';
        echo '<p>' . esc_html__( 'Abilita la protezione OTP da qualsiasi pagina o articolo e gestisci qui gli utenti autorizzati.', 'otp-in' ) . '</p>';
        echo '</div>';
    }

    /**
     * Render active pages list.
     */
    public function render_active_pages() {
        // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required to find protected posts.
        $protected_posts = get_posts( [
            'post_type'      => [ 'post', 'page' ],
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'meta_query'     => [
                [
                    'key'     => self::META_ENABLED,
                    'value'   => '1',
                    'compare' => '=',
                ],
            ],
        ] );

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__( 'Pagine attive', 'otp-in' ) . '</h1>';
        echo '<hr style="margin:15px 0;border:0;border-top:1px solid #ddd;">';
        if ( empty( $protected_posts ) ) {
            echo '<p>' . esc_html__( 'Nessuna pagina o articolo protetto.', 'otp-in' ) . '</p>';
        } else {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr>';
            echo '<th>' . esc_html__( 'Titolo', 'otp-in' ) . '</th>';
            echo '<th>' . esc_html__( 'Tipo', 'otp-in' ) . '</th>';
            echo '<th>' . esc_html__( 'Utenti autorizzati', 'otp-in' ) . '</th>';
            echo '<th>' . esc_html__( 'Azioni', 'otp-in' ) . '</th>';
            echo '</tr></thead><tbody>';
            
            foreach ( $protected_posts as $post ) {
                $allowed_ids = (array) get_post_meta( $post->ID, self::META_ALLOWED_USERS, true );
                $user_names = [];
                foreach ( $allowed_ids as $user_id ) {
                    $user_names[] = get_the_title( $user_id );
                }
                
                echo '<tr>';
                echo '<td><strong>' . esc_html( get_the_title( $post->ID ) ) . '</strong></td>';
                echo '<td>' . esc_html( get_post_type( $post->ID ) === 'page' ? __( 'Pagina', 'otp-in' ) : __( 'Articolo', 'otp-in' ) ) . '</td>';
                echo '<td>' . esc_html( implode( ', ', $user_names ) ) . '</td>';
                echo '<td><a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html__( 'Modifica', 'otp-in' ) . '</a></td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
        }
        
        echo '</div>';
    }

    /**
     * Register meta boxes.
     */
    public function register_meta_boxes() {
        foreach ( [ 'post', 'page' ] as $post_type ) {
            add_meta_box(
                'otp-access-users',
                __( 'OTP in', 'otp-in' ),
                [ $this, 'render_allowed_users_meta_box' ],
                $post_type,
                'side',
                'default'
            );
        }

        add_meta_box(
            'otp-access-user-details',
            __( 'Dettagli utente OTP', 'otp-in' ),
            [ $this, 'render_user_details_meta_box' ],
            self::POST_TYPE_USER,
            'normal',
            'default'
        );
    }

    /**
     * Render meta box with allowed users list.
     *
     * @param WP_Post $post
     */
    public function render_allowed_users_meta_box( $post ) {
        wp_nonce_field( 'otp_access_save_page_meta', 'otp_access_page_nonce' );

        $enabled  = (bool) get_post_meta( $post->ID, self::META_ENABLED, true );
        $selected = (array) get_post_meta( $post->ID, self::META_ALLOWED_USERS, true );
        $users    = $this->get_all_otp_users();

        echo '<p>';
        printf(
            '<label><input type="checkbox" name="otp_access_enabled" value="1" %s/> %s</label>',
            checked( $enabled, true, false ),
            esc_html__( 'Proteggi questo contenuto con OTP', 'otp-in' )
        );
        echo '</p>';

        if ( empty( $users ) ) {
            echo '<p>' . esc_html__( 'Non ci sono utenti OTP disponibili. Creane uno nella sezione "Utenti OTP".', 'otp-in' ) . '</p>';
            return;
        }

        echo '<p>' . esc_html__( 'Seleziona gli utenti autorizzati a richiedere il codice per questo contenuto.', 'otp-in' ) . ' <a href="#" id="otp-select-all" style="text-decoration:none;">' . esc_html__( 'Seleziona tutto', 'otp-in' ) . '</a></p>';
        echo '<div class="otp-access-user-list" style="max-height:180px;overflow:auto;padding:8px 12px;border:1px solid #ccd0d4;border-radius:4px;">';

        foreach ( $users as $user_post ) {
            $id      = (int) $user_post->ID;
            $checked = in_array( $id, $selected, true ) ? 'checked' : '';
            $label   = esc_html( get_the_title( $id ) );
            $email   = esc_html( get_post_meta( $id, self::META_EMAIL, true ) );
            $country_code = get_post_meta( $id, self::META_COUNTRY_CODE, true ) ?: '+39';
            $phone_number = get_post_meta( $id, self::META_PHONE, true );
            $phone   = esc_html( $phone_number ? $country_code . $phone_number : '' );

            echo '<label style="display:block;margin-bottom:6px;">';
            printf(
                '<input type="checkbox" name="otp_access_allowed_users[]" value="%1$d" %2$s/> %3$s <span style="color:#777;">&lt;%4$s • %5$s&gt;</span>',
                esc_attr( $id ),
                esc_attr( $checked ),
                esc_html( $label ),
                esc_html( $email ),
                esc_html( $phone )
            );
            echo '</label>';
        }

        echo '</div>';
        echo '<script>document.addEventListener("DOMContentLoaded",function(){var link=document.getElementById("otp-select-all");if(link){var allChecked=false;link.addEventListener("click",function(e){e.preventDefault();var checkboxes=document.querySelectorAll(".otp-access-user-list input[type=checkbox]");allChecked=!allChecked;checkboxes.forEach(function(cb){cb.checked=allChecked});link.textContent=allChecked?"' . esc_js( __( 'Deseleziona tutto', 'otp-in' ) ) . '":"' . esc_js( __( 'Seleziona tutto', 'otp-in' ) ) . '"})}})</script>';
    }

    /**
     * Render meta box for OTP user details.
     *
     * @param WP_Post $post
     */
    public function render_user_details_meta_box( $post ) {
        wp_nonce_field( 'otp_access_save_user_meta', 'otp_access_user_nonce' );

        $first_name = get_post_meta( $post->ID, self::META_FIRST_NAME, true );
        $last_name  = get_post_meta( $post->ID, self::META_LAST_NAME, true );
        $email      = get_post_meta( $post->ID, self::META_EMAIL, true );
        $phone      = get_post_meta( $post->ID, self::META_PHONE, true );
        $country_code = get_post_meta( $post->ID, self::META_COUNTRY_CODE, true ) ?: '+39';
        $duration   = get_post_meta( $post->ID, self::META_ACCESS_DURATION, true ) ?: '1_hour';
        $expiry     = get_post_meta( $post->ID, self::META_EXPIRY_DATE, true );
        $active     = get_post_meta( $post->ID, self::META_USER_ACTIVE, true );
        $active     = ( '' === $active ) ? '1' : $active;

        echo '<p style="display:flex;align-items:center;gap:10px;">';
        echo '<label class="otp-toggle-switch">';
        printf(
            '<input type="checkbox" name="otp_access_user_active" value="1" %s/>',
            checked( $active, '1', false )
        );
        echo '<span class="otp-toggle-slider"></span>';
        echo '</label>';
        echo '<span>' . esc_html__( 'Utente attivo', 'otp-in' ) . '</span>';
        echo '</p>';
        echo '<style>.otp-toggle-switch{position:relative;display:inline-block;width:36px;height:18px}.otp-toggle-switch input{opacity:0;width:0;height:0}.otp-toggle-slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#ccc;transition:.3s;border-radius:18px}.otp-toggle-slider:before{position:absolute;content:"";height:14px;width:14px;left:2px;bottom:2px;background-color:#fff;transition:.3s;border-radius:50%}.otp-toggle-switch input:checked+.otp-toggle-slider{background-color:#2271b1}.otp-toggle-switch input:checked+.otp-toggle-slider:before{transform:translateX(18px)}</style>';
        
        echo '<table class="form-table">';
        $this->render_text_row( __( 'Nome', 'otp-in' ), 'otp_access_first_name', $first_name );
        $this->render_text_row( __( 'Cognome', 'otp-in' ), 'otp_access_last_name', $last_name );
        $this->render_text_row( __( 'E-mail', 'otp-in' ), 'otp_access_email', $email, 'email' );
        // Campo telefono con prefisso
        echo '<tr><th scope="row"><label for="otp_access_phone">' . esc_html__( 'Numero di telefono', 'otp-in' ) . '</label></th>';
        echo '<td><div style="display:flex;gap:8px;">';
        echo '<select name="otp_access_country_code" style="width:auto;flex-shrink:0;">';
        $options = '<option value="+376">AD 🇦🇩 +376</option><option value="+971">AE 🇦🇪 +971</option><option value="+93">AF 🇦🇫 +93</option><option value="+355">AL 🇦🇱 +355</option><option value="+374">AM 🇦🇲 +374</option><option value="+244">AO 🇦🇴 +244</option><option value="+54">AR 🇦🇷 +54</option><option value="+43">AT 🇦🇹 +43</option><option value="+61">AU 🇦🇺 +61</option><option value="+297">AW 🇦🇼 +297</option><option value="+994">AZ 🇦🇿 +994</option><option value="+387">BA 🇧🇦 +387</option><option value="+880">BD 🇧🇩 +880</option><option value="+32">BE 🇧🇪 +32</option><option value="+226">BF 🇧🇫 +226</option><option value="+359">BG 🇧🇬 +359</option><option value="+973">BH 🇧🇭 +973</option><option value="+257">BI 🇧🇮 +257</option><option value="+229">BJ 🇧🇯 +229</option><option value="+673">BN 🇧🇳 +673</option><option value="+591">BO 🇧🇴 +591</option><option value="+599">BQ 🇧🇶 +599</option><option value="+55">BR 🇧🇷 +55</option><option value="+975">BT 🇧🇹 +975</option><option value="+267">BW 🇧🇼 +267</option><option value="+375">BY 🇧🇾 +375</option><option value="+501">BZ 🇧🇿 +501</option><option value="+1">CA 🇨🇦 +1</option><option value="+243">CD 🇨🇩 +243</option><option value="+236">CF 🇨🇫 +236</option><option value="+242">CG 🇨🇬 +242</option><option value="+41">CH 🇨🇭 +41</option><option value="+225">CI 🇨🇮 +225</option><option value="+682">CK 🇨🇰 +682</option><option value="+56">CL 🇨🇱 +56</option><option value="+237">CM 🇨🇲 +237</option><option value="+86">CN 🇨🇳 +86</option><option value="+57">CO 🇨🇴 +57</option><option value="+506">CR 🇨🇷 +506</option><option value="+53">CU 🇨🇺 +53</option><option value="+238">CV 🇨🇻 +238</option><option value="+357">CY 🇨🇾 +357</option><option value="+420">CZ 🇨🇿 +420</option><option value="+49">DE 🇩🇪 +49</option><option value="+253">DJ 🇩🇯 +253</option><option value="+45">DK 🇩🇰 +45</option><option value="+213">DZ 🇩🇿 +213</option><option value="+593">EC 🇪🇨 +593</option><option value="+372">EE 🇪🇪 +372</option><option value="+20">EG 🇪🇬 +20</option><option value="+291">ER 🇪🇷 +291</option><option value="+34">ES 🇪🇸 +34</option><option value="+251">ET 🇪🇹 +251</option><option value="+358">FI 🇫🇮 +358</option><option value="+679">FJ 🇫🇯 +679</option><option value="+500">FK 🇫🇰 +500</option><option value="+691">FM 🇫🇲 +691</option><option value="+298">FO 🇫🇴 +298</option><option value="+33">FR 🇫🇷 +33</option><option value="+241">GA 🇬🇦 +241</option><option value="+44">GB 🇬🇧 +44</option><option value="+1">GD 🇬🇩 +1</option><option value="+995">GE 🇬🇪 +995</option><option value="+594">GF 🇬🇫 +594</option><option value="+44">GG 🇬🇬 +44</option><option value="+233">GH 🇬🇭 +233</option><option value="+350">GI 🇬🇮 +350</option><option value="+299">GL 🇬🇱 +299</option><option value="+220">GM 🇬🇲 +220</option><option value="+224">GN 🇬🇳 +224</option><option value="+590">GP 🇬🇵 +590</option><option value="+240">GQ 🇬🇶 +240</option><option value="+30">GR 🇬🇷 +30</option><option value="+502">GT 🇬🇹 +502</option><option value="+1">GU 🇬🇺 +1</option><option value="+245">GW 🇬🇼 +245</option><option value="+592">GY 🇬🇾 +592</option><option value="+852">HK 🇭🇰 +852</option><option value="+504">HN 🇭🇳 +504</option><option value="+385">HR 🇭🇷 +385</option><option value="+509">HT 🇭🇹 +509</option><option value="+36">HU 🇭🇺 +36</option><option value="+62">ID 🇮🇩 +62</option><option value="+353">IE 🇮🇪 +353</option><option value="+972">IL 🇮🇱 +972</option><option value="+44">IM 🇮🇲 +44</option><option value="+91">IN 🇮🇳 +91</option><option value="+246">IO 🇮🇴 +246</option><option value="+964">IQ 🇮🇶 +964</option><option value="+98">IR 🇮🇷 +98</option><option value="+354">IS 🇮🇸 +354</option><option value="+39" selected>IT 🇮🇹 +39</option><option value="+44">JE 🇯🇪 +44</option><option value="+1">JM 🇯🇲 +1</option><option value="+962">JO 🇯🇴 +962</option><option value="+81">JP 🇯🇵 +81</option><option value="+254">KE 🇰🇪 +254</option><option value="+996">KG 🇰🇬 +996</option><option value="+855">KH 🇰🇭 +855</option><option value="+686">KI 🇰🇮 +686</option><option value="+269">KM 🇰🇲 +269</option><option value="+1">KN 🇰🇳 +1</option><option value="+850">KP 🇰🇵 +850</option><option value="+82">KR 🇰🇷 +82</option><option value="+965">KW 🇰🇼 +965</option><option value="+7">KZ 🇰🇿 +7</option><option value="+856">LA 🇱🇦 +856</option><option value="+961">LB 🇱🇧 +961</option><option value="+1">LC 🇱🇨 +1</option><option value="+423">LI 🇱🇮 +423</option><option value="+94">LK 🇱🇰 +94</option><option value="+231">LR 🇱🇷 +231</option><option value="+266">LS 🇱🇸 +266</option><option value="+370">LT 🇱🇹 +370</option><option value="+352">LU 🇱🇺 +352</option><option value="+371">LV 🇱🇻 +371</option><option value="+218">LY 🇱🇾 +218</option><option value="+212">MA 🇲🇦 +212</option><option value="+377">MC 🇲🇨 +377</option><option value="+373">MD 🇲🇩 +373</option><option value="+382">ME 🇲🇪 +382</option><option value="+261">MG 🇲🇬 +261</option><option value="+692">MH 🇲🇭 +692</option><option value="+389">MK 🇲🇰 +389</option><option value="+223">ML 🇲🇱 +223</option><option value="+95">MM 🇲🇲 +95</option><option value="+976">MN 🇲🇳 +976</option><option value="+853">MO 🇲🇴 +853</option><option value="+596">MQ 🇲🇶 +596</option><option value="+222">MR 🇲🇷 +222</option><option value="+356">MT 🇲🇹 +356</option><option value="+230">MU 🇲🇺 +230</option><option value="+960">MV 🇲🇻 +960</option><option value="+265">MW 🇲🇼 +265</option><option value="+52">MX 🇲🇽 +52</option><option value="+60">MY 🇲🇾 +60</option><option value="+258">MZ 🇲🇿 +258</option><option value="+264">NA 🇳🇦 +264</option><option value="+687">NC 🇳🇨 +687</option><option value="+227">NE 🇳🇪 +227</option><option value="+234">NG 🇳🇬 +234</option><option value="+505">NI 🇳🇮 +505</option><option value="+31">NL 🇳🇱 +31</option><option value="+47">NO 🇳🇴 +47</option><option value="+977">NP 🇳🇵 +977</option><option value="+674">NR 🇳🇷 +674</option><option value="+683">NU 🇳🇺 +683</option><option value="+64">NZ 🇳🇿 +64</option><option value="+968">OM 🇴🇲 +968</option><option value="+507">PA 🇵🇦 +507</option><option value="+51">PE 🇵🇪 +51</option><option value="+689">PF 🇵🇫 +689</option><option value="+675">PG 🇵🇬 +675</option><option value="+63">PH 🇵🇭 +63</option><option value="+92">PK 🇵🇰 +92</option><option value="+48">PL 🇵🇱 +48</option><option value="+508">PM 🇵🇲 +508</option><option value="+1">PR 🇵🇷 +1</option><option value="+970">PS 🇵🇸 +970</option><option value="+351">PT 🇵🇹 +351</option><option value="+680">PW 🇵🇼 +680</option><option value="+595">PY 🇵🇾 +595</option><option value="+974">QA 🇶🇦 +974</option><option value="+40">RO 🇷🇴 +40</option><option value="+381">RS 🇷🇸 +381</option><option value="+7">RU 🇷🇺 +7</option><option value="+250">RW 🇷🇼 +250</option><option value="+966">SA 🇸🇦 +966</option><option value="+677">SB 🇸🇧 +677</option><option value="+248">SC 🇸🇨 +248</option><option value="+249">SD 🇸🇩 +249</option><option value="+46">SE 🇸🇪 +46</option><option value="+65">SG 🇸🇬 +65</option><option value="+290">SH 🇸🇭 +290</option><option value="+386">SI 🇸🇮 +386</option><option value="+421">SK 🇸🇰 +421</option><option value="+232">SL 🇸🇱 +232</option><option value="+378">SM 🇸🇲 +378</option><option value="+221">SN 🇸🇳 +221</option><option value="+252">SO 🇸🇴 +252</option><option value="+597">SR 🇸🇷 +597</option><option value="+211">SS 🇸🇸 +211</option><option value="+239">ST 🇸🇹 +239</option><option value="+503">SV 🇸🇻 +503</option><option value="+963">SY 🇸🇾 +963</option><option value="+235">TD 🇹🇩 +235</option><option value="+228">TG 🇹🇬 +228</option><option value="+66">TH 🇹🇭 +66</option><option value="+992">TJ 🇹🇯 +992</option><option value="+690">TK 🇹🇰 +690</option><option value="+670">TL 🇹🇱 +670</option><option value="+993">TM 🇹🇲 +993</option><option value="+216">TN 🇹🇳 +216</option><option value="+676">TO 🇹🇴 +676</option><option value="+90">TR 🇹🇷 +90</option><option value="+1">TT 🇹🇹 +1</option><option value="+688">TV 🇹🇻 +688</option><option value="+886">TW 🇹🇼 +886</option><option value="+255">TZ 🇹🇿 +255</option><option value="+380">UA 🇺🇦 +380</option><option value="+256">UG 🇺🇬 +256</option><option value="+1">US 🇺🇸 +1</option><option value="+598">UY 🇺🇾 +598</option><option value="+998">UZ 🇺🇿 +998</option><option value="+379">VA 🇻🇦 +379</option><option value="+1">VC 🇻🇨 +1</option><option value="+58">VE 🇻🇪 +58</option><option value="+84">VN 🇻🇳 +84</option><option value="+678">VU 🇻🇺 +678</option><option value="+681">WF 🇼🇫 +681</option><option value="+685">WS 🇼🇸 +685</option><option value="+383">XK 🇽🇰 +383</option><option value="+967">YE 🇾🇪 +967</option><option value="+262">YT 🇾🇹 +262</option><option value="+27">ZA 🇿🇦 +27</option><option value="+260">ZM 🇿🇲 +260</option><option value="+263">ZW 🇿🇼 +263</option>';
        if ( $country_code !== '+39' ) {
            $options = str_replace( 'value="+39" selected', 'value="+39"', $options );
            $options = str_replace( 'value="' . esc_attr( $country_code ) . '"', 'value="' . esc_attr( $country_code ) . '" selected', $options );
        }
        echo wp_kses( $options, [ 'option' => [ 'value' => [], 'selected' => [] ] ] );
        echo '</select>';
        printf( '<input type="tel" class="regular-text" name="otp_access_phone" value="%s" style="flex:1;" placeholder="123456789" />', esc_attr( $phone ) );
        echo '</div></td></tr>';
        $this->render_duration_row( __( 'Durata accesso', 'otp-in' ), 'otp_access_duration', $duration );
        $expiry_time = get_post_meta( $post->ID, self::META_EXPIRY_TIME, true );
        echo '<tr><th scope="row"><label for="otp_access_expiry_date">' . esc_html__( 'Data e ora scadenza', 'otp-in' ) . '</label></th>';
        echo '<td><input type="date" id="otp_access_expiry_date" name="otp_access_expiry_date" value="' . esc_attr( $expiry ) . '" min="' . esc_attr( gmdate( 'Y-m-d' ) ) . '" style="width:auto;margin-right:10px;" />';
        echo '<input type="time" id="otp_access_expiry_time" name="otp_access_expiry_time" value="' . esc_attr( $expiry_time ) . '" style="width:auto;" /></td></tr>';
        echo '</table>';

        echo '<p class="description">' . esc_html__( 'Il titolo del post è usato come etichetta principale. Inserisci i dati del contatto per l’invio OTP.', 'otp-in' ) . '</p>';
    }

    /**
     * Helper to render a text input row.
     */
    protected function render_text_row( $label, $name, $value, $type = 'text' ) {
        printf(
            '<tr><th scope="row"><label for="%1$s">%2$s</label></th><td><input type="%3$s" class="regular-text" id="%1$s" name="%1$s" value="%4$s"/></td></tr>',
            esc_attr( $name ),
            esc_html( $label ),
            esc_attr( $type ),
            esc_attr( $value )
        );
    }

    /**
     * Helper to render duration select row.
     */
    protected function render_duration_row( $label, $name, $value ) {
        $options = [
            '15_min'    => __( '15 minuti', 'otp-in' ),
            '30_min'    => __( '30 minuti', 'otp-in' ),
            '1_hour'    => __( '1 ora', 'otp-in' ),
            '6_hours'   => __( '6 ore', 'otp-in' ),
            '12_hours'  => __( '12 ore', 'otp-in' ),
            '24_hours'  => __( '24 ore', 'otp-in' ),
            '2_days'    => __( '2 giorni', 'otp-in' ),
            'unlimited' => __( 'Senza limite', 'otp-in' ),
        ];
        
        echo '<tr><th scope="row"><label for="' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label></th><td>';
        echo '<select id="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '">';
        foreach ( $options as $key => $text ) {
            printf( '<option value="%s"%s>%s</option>', esc_attr( $key ), selected( $value, $key, false ), esc_html( $text ) );
        }
        echo '</select></td></tr>';
    }

    /**
     * Save meta for protected pages.
     */
    public function save_content_meta( $post_id, $post ) {
        if ( 'revision' === $post->post_type || self::POST_TYPE_USER === $post->post_type ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( ! isset( $_POST['otp_access_page_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['otp_access_page_nonce'] ) ), 'otp_access_save_page_meta' ) ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $enabled       = isset( $_POST['otp_access_enabled'] ) ? (bool) intval( $_POST['otp_access_enabled'] ) : false;
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via array_map intval below.
        $allowed_users = isset( $_POST['otp_access_allowed_users'] ) ? (array) wp_unslash( $_POST['otp_access_allowed_users'] ) : [];
        $allowed_users = array_map( 'intval', $allowed_users );
        $allowed_users = array_filter( $allowed_users );

        if ( $enabled ) {
            update_post_meta( $post_id, self::META_ENABLED, 1 );
            update_post_meta( $post_id, self::META_ALLOWED_USERS, array_values( array_unique( $allowed_users ) ) );
        } else {
            delete_post_meta( $post_id, self::META_ENABLED );
            delete_post_meta( $post_id, self::META_ALLOWED_USERS );
        }
    }

    /**
     * Save meta for OTP users.
     */
    public function save_user_meta( $post_id, $post ) {
        if ( ! isset( $_POST['otp_access_user_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['otp_access_user_nonce'] ) ), 'otp_access_save_user_meta' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $first_name = isset( $_POST['otp_access_first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_first_name'] ) ) : '';
        $last_name  = isset( $_POST['otp_access_last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_last_name'] ) ) : '';
        $email      = isset( $_POST['otp_access_email'] ) ? sanitize_email( wp_unslash( $_POST['otp_access_email'] ) ) : '';
        $country_code = isset( $_POST['otp_access_country_code'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_country_code'] ) ) : '+39';
        $phone_number = isset( $_POST['otp_access_phone'] ) ? preg_replace( '/[^0-9]/', '', wp_unslash( $_POST['otp_access_phone'] ) ) : '';
        $duration   = isset( $_POST['otp_access_duration'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_duration'] ) ) : '1_hour';
        $expiry      = isset( $_POST['otp_access_expiry_date'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_expiry_date'] ) ) : '';
        $expiry_time = isset( $_POST['otp_access_expiry_time'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_expiry_time'] ) ) : '';
        $active      = isset( $_POST['otp_access_user_active'] ) ? '1' : '0';

        update_post_meta( $post_id, self::META_FIRST_NAME, $first_name );
        update_post_meta( $post_id, self::META_LAST_NAME, $last_name );
        update_post_meta( $post_id, self::META_EMAIL, $email );
        update_post_meta( $post_id, self::META_COUNTRY_CODE, $country_code );
        update_post_meta( $post_id, self::META_PHONE, $phone_number );
        update_post_meta( $post_id, self::META_ACCESS_DURATION, $duration );
        update_post_meta( $post_id, self::META_EXPIRY_DATE, $expiry );
        update_post_meta( $post_id, self::META_EXPIRY_TIME, $expiry_time );
        update_post_meta( $post_id, self::META_USER_ACTIVE, $active );
    }

    /**
     * Configure admin columns for pages.
     */
    public function add_content_columns( $columns ) {
        $columns['otp_access_status'] = __( 'OTP in', 'otp-in' );
        return $columns;
    }

    /**
     * Configure admin columns for users.
     */
    public function columns_for_users( $columns ) {
        $columns['otp_access_full_name'] = __( 'Nome completo', 'otp-in' );
        $columns['otp_access_email']     = __( 'E-mail', 'otp-in' );
        $columns['otp_access_phone']     = __( 'Telefono', 'otp-in' );
        $columns['otp_access_active']    = __( 'Stato', 'otp-in' );
        return $columns;
    }

    /**
     * Render custom columns for pages.
     */
    public function render_content_columns( $column, $post_id ) {
        if ( 'otp_access_status' !== $column ) {
            return;
        }

        if ( ! $this->is_post_protected( $post_id ) ) {
            printf( '&#10005; %s', esc_html__( 'Non abilitato', 'otp-in' ) );
            return;
        }

        $ids = (array) get_post_meta( $post_id, self::META_ALLOWED_USERS, true );
        if ( empty( $ids ) ) {
            printf(
                '&#10003; <strong>%1$s</strong><br/><span style="color:#6b7280;font-size:11px;">%2$s</span>',
                esc_html__( 'Abilitato', 'otp-in' ),
                esc_html__( 'Nessun utente', 'otp-in' )
            );
            return;
        }

        $names = [];
        foreach ( $ids as $id ) {
            $names[] = esc_html( get_the_title( (int) $id ) );
        }

        printf(
            '&#10003; <strong>%1$s</strong><br/><span style="color:#6b7280;font-size:11px;">%2$s</span>',
            esc_html__( 'Abilitato', 'otp-in' ),
            esc_html( implode( ', ', $names ) )
        );
    }

    /**
     * Render custom columns for users.
     */
    public function render_user_columns( $column, $post_id ) {
        switch ( $column ) {
            case 'otp_access_full_name':
                $first = get_post_meta( $post_id, self::META_FIRST_NAME, true );
                $last  = get_post_meta( $post_id, self::META_LAST_NAME, true );
                echo esc_html( trim( $first . ' ' . $last ) );
                break;
            case 'otp_access_email':
                echo esc_html( get_post_meta( $post_id, self::META_EMAIL, true ) );
                break;
            case 'otp_access_phone':
                $country_code = get_post_meta( $post_id, self::META_COUNTRY_CODE, true ) ?: '+39';
                $phone_number = get_post_meta( $post_id, self::META_PHONE, true );
                echo esc_html( $phone_number ? $country_code . $phone_number : '' );
                break;
            case 'otp_access_active':
                $active = get_post_meta( $post_id, self::META_USER_ACTIVE, true );
                if ( '1' === $active || '' === $active ) {
                    echo '<span style="color:#46b450;">&#10003; ' . esc_html__( 'Attivo', 'otp-in' ) . '</span>';
                } else {
                    echo '<span style="color:#dc3232;">&#10005; ' . esc_html__( 'Non attivo', 'otp-in' ) . '</span>';
                }
                break;
        }
    }

    /**
     * Make email column sortable.
     */
    public function sortable_user_columns( $columns ) {
        $columns['otp_access_email'] = 'otp_access_email';
        return $columns;
    }

    /**
     * Handle sorting for custom columns.
     */
    public function handle_user_sorting( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() || self::POST_TYPE_USER !== $query->get( 'post_type' ) ) {
            return;
        }

        if ( 'otp_access_email' === $query->get( 'orderby' ) ) {
            $query->set( 'meta_key', self::META_EMAIL );
            $query->set( 'orderby', 'meta_value' );
        }
    }

    /**
     * Custom placeholder text for titles.
     */
    public function filter_enter_title_here( $text, $post ) {
        if ( in_array( $post->post_type, [ 'post', 'page' ], true ) ) {
            return __( 'Titolo contenuto', 'otp-in' );
        }
        if ( self::POST_TYPE_USER === $post->post_type ) {
            return __( 'Nome utente OTP', 'otp-in' );
        }
        return $text;
    }

    /**
     * Filter template for OTP pages.
     */
    public function filter_single_template( $template ) {
        if ( is_singular() ) {
            $post_id = get_queried_object_id();
            if ( $post_id && $this->is_post_protected( $post_id ) && ! $this->visitor_has_access( $post_id ) ) {
                $custom = OTP_ACCESS_MANAGER_PATH . 'templates/single-otp-secure-page.php';
                if ( file_exists( $custom ) ) {
                    return $custom;
                }
            }
        }
        return $template;
    }

    /**
     * Register shortcode fallback.
     */
    public function register_shortcodes() {
        add_shortcode( 'otp_access_form', [ $this, 'render_shortcode_form' ] );
    }

    /**
     * Render shortcode for embedding forms elsewhere.
     */
    public function render_shortcode_form( $atts, $content = null ) {
        $post_id = get_the_ID();
        if ( ! $post_id || ! $this->is_post_protected( $post_id ) ) {
            return '';
        }

        ob_start();
        $context = $this->get_view_context( $post_id );
        $this->render_status_notice( $post_id );

        if ( in_array( $context['status'], [ 'code_sent', 'invalid_code' ], true ) ) {
            $this->render_verify_form( $post_id );
        }

        $this->render_request_form( $post_id );
        return ob_get_clean();
    }

    /**
     * Handle frontend POST submissions.
     */
    public function handle_frontend_submission() {
        if ( ! is_singular() ) {
            return;
        }

        $post_id = get_queried_object_id();
        if ( ! $post_id || ! $this->is_post_protected( $post_id ) ) {
            return;
        }

        if ( empty( $_POST['otp_access_action'] ) ) {
            return;
        }

        $action = sanitize_text_field( wp_unslash( $_POST['otp_access_action'] ) );
        $nonce  = isset( $_POST['otp_access_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_nonce'] ) ) : '';

        if ( ! wp_verify_nonce( $nonce, 'otp_access_' . $action . '_' . $post_id ) ) {
            return;
        }

        if ( 'request' === $action ) {
            $this->process_request_action( $post_id );
        } elseif ( 'verify' === $action ) {
            $this->process_verify_action( $post_id );
        }
    }

    /**
     * Process OTP request.
     */
    protected function process_request_action( $post_id ) {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified in handle_frontend_submission.
        $first_name = isset( $_POST['otp_access_first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_first_name'] ) ) : '';
        $last_name  = isset( $_POST['otp_access_last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_last_name'] ) ) : '';
        $country_code = isset( $_POST['otp_access_country_code'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_country_code'] ) ) : '+39';
        $phone_number = isset( $_POST['otp_access_phone'] ) ? preg_replace( '/[^0-9]/', '', wp_unslash( $_POST['otp_access_phone'] ) ) : '';
        $phone = $country_code . $phone_number;
        // phpcs:enable WordPress.Security.NonceVerification.Missing
        $user_post = $this->find_allowed_user_by_identity( $post_id, $first_name, $last_name, $phone );

        if ( ! $phone || ! $user_post ) {
            $this->redirect_with_status( $post_id, 'user_not_allowed', $first_name, $last_name, $phone, $country_code, $phone_number );
            return;
        }

        $active = get_post_meta( $user_post->ID, self::META_USER_ACTIVE, true );
        if ( '0' === $active ) {
            $this->redirect_with_status( $post_id, 'access_disabled', $first_name, $last_name, $phone, $country_code, $phone_number );
            return;
        }

        $expiry = get_post_meta( $user_post->ID, self::META_EXPIRY_DATE, true );
        if ( $expiry ) {
            $expiry_time_str = get_post_meta( $user_post->ID, self::META_EXPIRY_TIME, true );
            $expiry_datetime = $expiry . ' ' . ( $expiry_time_str ?: '23:59:59' );
            $expiry_timestamp = strtotime( $expiry_datetime );
            if ( $expiry_timestamp && $expiry_timestamp < time() ) {
                $this->redirect_with_status( $post_id, 'access_expired', $first_name, $last_name, $phone, $country_code, $phone_number );
                return;
            }
        }

        $code = wp_rand( 100000, 999999 );
        $this->store_otp_code( $post_id, $user_post->ID, $code );
        $this->send_otp_email( $user_post, $post_id, $code );

        $this->redirect_with_status( $post_id, 'code_sent', $first_name, $last_name, $phone, $country_code, $phone_number );
    }

    /**
     * Process OTP verification.
     */
    protected function process_verify_action( $post_id ) {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified in handle_frontend_submission.
        $first_name = isset( $_POST['otp_access_first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_first_name'] ) ) : '';
        $last_name  = isset( $_POST['otp_access_last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_last_name'] ) ) : '';
        $country_code = isset( $_POST['otp_access_country_code'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_country_code'] ) ) : '+39';
        $phone_number = isset( $_POST['otp_access_phone'] ) ? preg_replace( '/[^0-9]/', '', wp_unslash( $_POST['otp_access_phone'] ) ) : '';
        $phone = $country_code . $phone_number;
        $code       = isset( $_POST['otp_access_code'] ) ? sanitize_text_field( wp_unslash( $_POST['otp_access_code'] ) ) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Missing
        $user_post = $this->find_allowed_user_by_identity( $post_id, $first_name, $last_name, $phone );

        if ( ! $phone || ! $user_post ) {
            $this->redirect_with_status( $post_id, 'user_not_allowed', $first_name, $last_name, $phone, $country_code, $phone_number );
            return;
        }

        if ( ! $code || ! $this->validate_otp_code( $post_id, $user_post->ID, $code ) ) {
            $this->redirect_with_status( $post_id, 'invalid_code', $first_name, $last_name, $phone, $country_code, $phone_number );
            return;
        }

        $this->grant_access( $post_id, $user_post->ID );
        wp_safe_redirect( get_permalink( $post_id ) );
        exit;
    }

    /**
     * Store OTP code in transient.
     */
    protected function store_otp_code( $post_id, $user_id, $code ) {
        $key = self::OTP_TRANSIENT_PREFIX . $post_id . '_' . $user_id;
        set_transient( $key, wp_hash_password( (string) $code ), 15 * MINUTE_IN_SECONDS );
    }

    /**
     * Validate OTP code.
     */
    protected function validate_otp_code( $post_id, $user_id, $code ) {
        $key     = self::OTP_TRANSIENT_PREFIX . $post_id . '_' . $user_id;
        $hashed  = get_transient( $key );
        if ( ! $hashed ) {
            return false;
        }

        $is_valid = wp_check_password( (string) $code, $hashed );
        
        if ( $is_valid ) {
            delete_transient( $key );
        }
        
        return $is_valid;
    }

    /**
     * Send OTP via email.
     */
    protected function send_otp_email( WP_Post $user_post, $post_id, $code ) {
        $email = get_post_meta( $user_post->ID, self::META_EMAIL, true );
        if ( ! $email ) {
            return;
        }

        /* translators: %s: Page or post title */
        $subject = sprintf( __( 'Codice OTP per "%s"', 'otp-in' ), get_the_title( $post_id ) );
        $user_name = esc_html( get_the_title( $user_post->ID ) );
        $page_title = esc_html( get_the_title( $post_id ) );
        $site_name = esc_html( get_bloginfo( 'name' ) );
        /* translators: %s: User name */
        $greeting = sprintf( __( 'Ciao %s,', 'otp-in' ), $user_name );
        /* translators: %s: Page or post title */
        $intro = sprintf( __( 'Ecco il tuo codice per accedere a <strong>%s</strong>', 'otp-in' ), $page_title );
        $expiry = __( 'Il codice scade tra 15 minuti', 'otp-in' );
        $title = __( 'Codice di accesso OTP', 'otp-in' );
        
        // Get WordPress Site Icon or fallback
        $logo_html = '';
        $site_icon_id = get_option( 'site_icon' );
        if ( $site_icon_id ) {
            $icon_url = wp_get_attachment_url( $site_icon_id );
            if ( $icon_url ) {
                $logo_html = '<img src="' . esc_url( $icon_url ) . '" alt="' . esc_attr( $site_name ) . '" style="width:64px;height:64px;margin:0 auto 24px;border-radius:8px;" />';
            }
        }
        if ( ! $logo_html ) {
            $logo_html = '<div style="width:64px;height:64px;margin:0 auto 24px;background:#2271b1;border-radius:50%;display:flex;align-items:center;justify-content:center;"><svg width="32" height="32" fill="white" viewBox="0 0 24 24"><path d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M12,7C13.4,7 14.8,8.6 14.8,10.5V11.5C15.4,11.5 16,12.4 16,13V16C16,17.4 15.4,18 14.8,18H9.2C8.6,18 8,17.4 8,16V13C8,12.4 8.6,11.5 9.2,11.5V10.5C9.2,8.6 10.6,7 12,7M12,8.2C11.2,8.2 10.5,8.7 10.5,10.5V11.5H13.5V10.5C13.5,8.7 12.8,8.2 12,8.2Z"/></svg></div>';
        }
        
        $message = sprintf(
            '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head><body style="margin:0;padding:0;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;background-color:#f3f4f6;"><table width="100%%" cellpadding="0" cellspacing="0" style="background-color:#f3f4f6;padding:40px 20px;"><tr><td align="center"><table width="100%%" cellpadding="0" cellspacing="0" style="max-width:600px;background-color:#ffffff;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1);"><tr><td style="padding:40px 32px;text-align:center;">%s<h1 style="margin:0 0 24px;font-size:24px;color:#111827;">%s</h1><p style="margin:0 0 32px;font-size:16px;color:#6b7280;line-height:1.5;">%s<br>%s</p><div style="background-color:#f9fafb;border:2px solid #e5e7eb;border-radius:8px;padding:24px;margin:0 0 32px;"><div style="font-size:36px;font-weight:700;color:#111827;letter-spacing:8px;">%s</div></div><p style="margin:0;font-size:14px;color:#9ca3af;">%s</p></td></tr></table><p style="margin:20px 0 0;font-size:12px;color:#9ca3af;text-align:center;">%s</p></td></tr></table></body></html>',
            $logo_html,
            $title,
            $greeting,
            $intro,
            esc_html( $code ),
            $expiry,
            $site_name
        );

        wp_mail( $email, $subject, $message, [ 'Content-Type: text/html; charset=UTF-8' ] );
    }

    /**
     * Grant access by setting cookie & transient.
     */
    protected function grant_access( $post_id, $user_id ) {
        $duration = get_post_meta( $user_id, self::META_ACCESS_DURATION, true ) ?: '1_hour';
        
        $durations = [
            '15_min'    => 15 * MINUTE_IN_SECONDS,
            '30_min'    => 30 * MINUTE_IN_SECONDS,
            '1_hour'    => HOUR_IN_SECONDS,
            '6_hours'   => 6 * HOUR_IN_SECONDS,
            '12_hours'  => 12 * HOUR_IN_SECONDS,
            '24_hours'  => 24 * HOUR_IN_SECONDS,
            '2_days'    => 2 * DAY_IN_SECONDS,
            'unlimited' => YEAR_IN_SECONDS,
        ];
        
        $seconds = isset( $durations[ $duration ] ) ? $durations[ $duration ] : HOUR_IN_SECONDS;
        
        $token = wp_generate_password( 20, false, false );
        $key   = self::TOKEN_TRANSIENT_PREFIX . $post_id . '_' . $token;

        set_transient( $key, $user_id, $seconds );

        $cookie_name = self::COOKIE_PREFIX . $post_id;
        $expire      = time() + $seconds;
        $path        = '/';
        $domain      = '';
        $secure      = is_ssl();
        $httponly    = false;

        setcookie( $cookie_name, $token, $expire, $path, $domain, $secure, $httponly );
        $_COOKIE[ $cookie_name ] = $token;
    }

    /**
     * Redirect to same page with status.
     */
    protected function redirect_with_status( $post_id, $status, $first_name = '', $last_name = '', $phone = '', $country_code = '', $phone_number = '' ) {
        $url = get_permalink( $post_id );
        if ( ! $url ) {
            wp_safe_redirect( home_url() );
            exit;
        }

        $args = [ 'otp_status' => $status ];
        if ( $first_name ) {
            $args['otp_first_name'] = $first_name;
        }
        if ( $last_name ) {
            $args['otp_last_name'] = $last_name;
        }
        if ( $country_code && $phone_number ) {
            $args['otp_country_code'] = $country_code;
            $args['otp_phone'] = $phone_number;
        } elseif ( $phone ) {
            if ( preg_match( '/^(\+\d{1,4})(\d+)$/', $phone, $matches ) ) {
                $args['otp_country_code'] = $matches[1];
                $args['otp_phone'] = $matches[2];
            } else {
                $args['otp_phone'] = preg_replace( '/[^0-9]/', '', $phone );
                $args['otp_country_code'] = '+39';
            }
        }

        wp_safe_redirect( esc_url_raw( add_query_arg( $args, $url ) ) );
        exit;
    }

    /**
     * Determine if current visitor has access.
     */
    public function is_post_protected( $post_id ) {
        if ( ! $post_id ) {
            return false;
        }

        if ( self::POST_TYPE_USER === get_post_type( $post_id ) ) {
            return false;
        }

        $enabled = get_post_meta( $post_id, self::META_ENABLED, true );
        
        return (bool) $enabled;
    }

    /**
     * Determine if current visitor has access.
     */
    public function visitor_has_access( $post_id ) {
        $cookie_name = self::COOKIE_PREFIX . $post_id;
        
        if ( empty( $_COOKIE[ $cookie_name ] ) ) {
            return false;
        }

        $token = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );
        $key   = self::TOKEN_TRANSIENT_PREFIX . $post_id . '_' . $token;
        $user_id = get_transient( $key );
        
        if ( ! $user_id ) {
            return false;
        }
        
        $expiry = get_post_meta( $user_id, self::META_EXPIRY_DATE, true );
        if ( $expiry ) {
            $expiry_time_str = get_post_meta( $user_id, self::META_EXPIRY_TIME, true );
            $expiry_datetime = $expiry . ' ' . ( $expiry_time_str ?: '23:59:59' );
            $expiry_timestamp = strtotime( $expiry_datetime );
            if ( $expiry_timestamp && $expiry_timestamp < time() ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Provide context for template rendering.
     */
    public function get_view_context( $post_id ) {
        if ( isset( $this->view_context[ $post_id ] ) ) {
            return $this->view_context[ $post_id ];
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only display data from redirect.
        $status       = isset( $_GET['otp_status'] ) ? sanitize_key( wp_unslash( $_GET['otp_status'] ) ) : '';
        $first_name   = isset( $_GET['otp_first_name'] ) ? sanitize_text_field( wp_unslash( $_GET['otp_first_name'] ) ) : '';
        $last_name    = isset( $_GET['otp_last_name'] ) ? sanitize_text_field( wp_unslash( $_GET['otp_last_name'] ) ) : '';
        $country_code = isset( $_GET['otp_country_code'] ) ? sanitize_text_field( wp_unslash( $_GET['otp_country_code'] ) ) : '+39';
        $phone_number = isset( $_GET['otp_phone'] ) ? sanitize_text_field( wp_unslash( $_GET['otp_phone'] ) ) : '';
        $phone        = $phone_number ? $country_code . $phone_number : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $this->view_context[ $post_id ] = [
            'status'       => $status,
            'first_name'   => $first_name,
            'last_name'    => $last_name,
            'phone'        => $phone,
            'country_code' => $country_code,
            'phone_number' => $phone_number,
        ];

        return $this->view_context[ $post_id ];
    }

    /**
     * Render OTP request form.
     */
    public function render_request_form( $post_id ) {
        $context = $this->get_view_context( $post_id );
        $first_name   = $context['first_name'];
        $last_name    = $context['last_name'];
        $country_code = isset( $context['country_code'] ) ? $context['country_code'] : '+39';
        $phone_number = isset( $context['phone_number'] ) ? $context['phone_number'] : '';
        $require_first_name = $this->get_option( self::OPTION_REQUIRE_FIRST_NAME );
        $require_last_name = $this->get_option( self::OPTION_REQUIRE_LAST_NAME );

        echo '<form method="post" class="otp-access-form otp-access-request">';
        wp_nonce_field( 'otp_access_request_' . $post_id, 'otp_access_nonce' );
        echo '<input type="hidden" name="otp_access_action" value="request" />';
        if ( $require_first_name ) {
            echo '<div class="otp-access-field">';
            echo '<label for="otp-access-first-name">' . esc_html__( 'Nome', 'otp-in' ) . '</label>';
            printf( '<input required type="text" id="otp-access-first-name" name="otp_access_first_name" autocomplete="given-name" value="%s" />', esc_attr( $first_name ) );
            echo '</div>';
        }
        if ( $require_last_name ) {
            echo '<div class="otp-access-field">';
            echo '<label for="otp-access-last-name">' . esc_html__( 'Cognome', 'otp-in' ) . '</label>';
            printf( '<input required type="text" id="otp-access-last-name" name="otp_access_last_name" autocomplete="family-name" value="%s" />', esc_attr( $last_name ) );
            echo '</div>';
        }
        echo '<div class="otp-access-field">';
        echo '<label for="otp-access-phone">' . esc_html__( 'Numero di telefono', 'otp-in' ) . '</label>';
        echo '<div style="display:flex;gap:8px;">';
        echo '<select name="otp_access_country_code" style="width:auto;flex-shrink:0;" required>';
        $options = '<option value="+376">AD 🇦🇩 +376</option><option value="+971">AE 🇦🇪 +971</option><option value="+93">AF 🇦🇫 +93</option><option value="+355">AL 🇦🇱 +355</option><option value="+374">AM 🇦🇲 +374</option><option value="+244">AO 🇦🇴 +244</option><option value="+54">AR 🇦🇷 +54</option><option value="+43">AT 🇦🇹 +43</option><option value="+61">AU 🇦🇺 +61</option><option value="+297">AW 🇦🇼 +297</option><option value="+994">AZ 🇦🇿 +994</option><option value="+387">BA 🇧🇦 +387</option><option value="+880">BD 🇧🇩 +880</option><option value="+32">BE 🇧🇪 +32</option><option value="+226">BF 🇧🇫 +226</option><option value="+359">BG 🇧🇬 +359</option><option value="+973">BH 🇧🇭 +973</option><option value="+257">BI 🇧🇮 +257</option><option value="+229">BJ 🇧🇯 +229</option><option value="+673">BN 🇧🇳 +673</option><option value="+591">BO 🇧🇴 +591</option><option value="+599">BQ 🇧🇶 +599</option><option value="+55">BR 🇧🇷 +55</option><option value="+975">BT 🇧🇹 +975</option><option value="+267">BW 🇧🇼 +267</option><option value="+375">BY 🇧🇾 +375</option><option value="+501">BZ 🇧🇿 +501</option><option value="+1">CA 🇨🇦 +1</option><option value="+243">CD 🇨🇩 +243</option><option value="+236">CF 🇨🇫 +236</option><option value="+242">CG 🇨🇬 +242</option><option value="+41">CH 🇨🇭 +41</option><option value="+225">CI 🇨🇮 +225</option><option value="+682">CK 🇨🇰 +682</option><option value="+56">CL 🇨🇱 +56</option><option value="+237">CM 🇨🇲 +237</option><option value="+86">CN 🇨🇳 +86</option><option value="+57">CO 🇨🇴 +57</option><option value="+506">CR 🇨🇷 +506</option><option value="+53">CU 🇨🇺 +53</option><option value="+238">CV 🇨🇻 +238</option><option value="+357">CY 🇨🇾 +357</option><option value="+420">CZ 🇨🇿 +420</option><option value="+49">DE 🇩🇪 +49</option><option value="+253">DJ 🇩🇯 +253</option><option value="+45">DK 🇩🇰 +45</option><option value="+213">DZ 🇩🇿 +213</option><option value="+593">EC 🇪🇨 +593</option><option value="+372">EE 🇪🇪 +372</option><option value="+20">EG 🇪🇬 +20</option><option value="+291">ER 🇪🇷 +291</option><option value="+34">ES 🇪🇸 +34</option><option value="+251">ET 🇪🇹 +251</option><option value="+358">FI 🇫🇮 +358</option><option value="+679">FJ 🇫🇯 +679</option><option value="+500">FK 🇫🇰 +500</option><option value="+691">FM 🇫🇲 +691</option><option value="+298">FO 🇫🇴 +298</option><option value="+33">FR 🇫🇷 +33</option><option value="+241">GA 🇬🇦 +241</option><option value="+44">GB 🇬🇧 +44</option><option value="+1">GD 🇬🇩 +1</option><option value="+995">GE 🇬🇪 +995</option><option value="+594">GF 🇬🇫 +594</option><option value="+44">GG 🇬🇬 +44</option><option value="+233">GH 🇬🇭 +233</option><option value="+350">GI 🇬🇮 +350</option><option value="+299">GL 🇬🇱 +299</option><option value="+220">GM 🇬🇲 +220</option><option value="+224">GN 🇬🇳 +224</option><option value="+590">GP 🇬🇵 +590</option><option value="+240">GQ 🇬🇶 +240</option><option value="+30">GR 🇬🇷 +30</option><option value="+502">GT 🇬🇹 +502</option><option value="+1">GU 🇬🇺 +1</option><option value="+245">GW 🇬🇼 +245</option><option value="+592">GY 🇬🇾 +592</option><option value="+852">HK 🇭🇰 +852</option><option value="+504">HN 🇭🇳 +504</option><option value="+385">HR 🇭🇷 +385</option><option value="+509">HT 🇭🇹 +509</option><option value="+36">HU 🇭🇺 +36</option><option value="+62">ID 🇮🇩 +62</option><option value="+353">IE 🇮🇪 +353</option><option value="+972">IL 🇮🇱 +972</option><option value="+44">IM 🇮🇲 +44</option><option value="+91">IN 🇮🇳 +91</option><option value="+246">IO 🇮🇴 +246</option><option value="+964">IQ 🇮🇶 +964</option><option value="+98">IR 🇮🇷 +98</option><option value="+354">IS 🇮🇸 +354</option><option value="+39" selected>IT 🇮🇹 +39</option><option value="+44">JE 🇯🇪 +44</option><option value="+1">JM 🇯🇲 +1</option><option value="+962">JO 🇯🇴 +962</option><option value="+81">JP 🇯🇵 +81</option><option value="+254">KE 🇰🇪 +254</option><option value="+996">KG 🇰🇬 +996</option><option value="+855">KH 🇰🇭 +855</option><option value="+686">KI 🇰🇮 +686</option><option value="+269">KM 🇰🇲 +269</option><option value="+1">KN 🇰🇳 +1</option><option value="+850">KP 🇰🇵 +850</option><option value="+82">KR 🇰🇷 +82</option><option value="+965">KW 🇰🇼 +965</option><option value="+7">KZ 🇰🇿 +7</option><option value="+856">LA 🇱🇦 +856</option><option value="+961">LB 🇱🇧 +961</option><option value="+1">LC 🇱🇨 +1</option><option value="+423">LI 🇱🇮 +423</option><option value="+94">LK 🇱🇰 +94</option><option value="+231">LR 🇱🇷 +231</option><option value="+266">LS 🇱🇸 +266</option><option value="+370">LT 🇱🇹 +370</option><option value="+352">LU 🇱🇺 +352</option><option value="+371">LV 🇱🇻 +371</option><option value="+218">LY 🇱🇾 +218</option><option value="+212">MA 🇲🇦 +212</option><option value="+377">MC 🇲🇨 +377</option><option value="+373">MD 🇲🇩 +373</option><option value="+382">ME 🇲🇪 +382</option><option value="+261">MG 🇲🇬 +261</option><option value="+692">MH 🇲🇭 +692</option><option value="+389">MK 🇲🇰 +389</option><option value="+223">ML 🇲🇱 +223</option><option value="+95">MM 🇲🇲 +95</option><option value="+976">MN 🇲🇳 +976</option><option value="+853">MO 🇲🇴 +853</option><option value="+596">MQ 🇲🇶 +596</option><option value="+222">MR 🇲🇷 +222</option><option value="+356">MT 🇲🇹 +356</option><option value="+230">MU 🇲🇺 +230</option><option value="+960">MV 🇲🇻 +960</option><option value="+265">MW 🇲🇼 +265</option><option value="+52">MX 🇲🇽 +52</option><option value="+60">MY 🇲🇾 +60</option><option value="+258">MZ 🇲🇿 +258</option><option value="+264">NA 🇳🇦 +264</option><option value="+687">NC 🇳🇨 +687</option><option value="+227">NE 🇳🇪 +227</option><option value="+234">NG 🇳🇬 +234</option><option value="+505">NI 🇳🇮 +505</option><option value="+31">NL 🇳🇱 +31</option><option value="+47">NO 🇳🇴 +47</option><option value="+977">NP 🇳🇵 +977</option><option value="+674">NR 🇳🇷 +674</option><option value="+683">NU 🇳🇺 +683</option><option value="+64">NZ 🇳🇿 +64</option><option value="+968">OM 🇴🇲 +968</option><option value="+507">PA 🇵🇦 +507</option><option value="+51">PE 🇵🇪 +51</option><option value="+689">PF 🇵🇫 +689</option><option value="+675">PG 🇵🇬 +675</option><option value="+63">PH 🇵🇭 +63</option><option value="+92">PK 🇵🇰 +92</option><option value="+48">PL 🇵🇱 +48</option><option value="+508">PM 🇵🇲 +508</option><option value="+1">PR 🇵🇷 +1</option><option value="+970">PS 🇵🇸 +970</option><option value="+351">PT 🇵🇹 +351</option><option value="+680">PW 🇵🇼 +680</option><option value="+595">PY 🇵🇾 +595</option><option value="+974">QA 🇶🇦 +974</option><option value="+40">RO 🇷🇴 +40</option><option value="+381">RS 🇷🇸 +381</option><option value="+7">RU 🇷🇺 +7</option><option value="+250">RW 🇷🇼 +250</option><option value="+966">SA 🇸🇦 +966</option><option value="+677">SB 🇸🇧 +677</option><option value="+248">SC 🇸🇨 +248</option><option value="+249">SD 🇸🇩 +249</option><option value="+46">SE 🇸🇪 +46</option><option value="+65">SG 🇸🇬 +65</option><option value="+290">SH 🇸🇭 +290</option><option value="+386">SI 🇸🇮 +386</option><option value="+421">SK 🇸🇰 +421</option><option value="+232">SL 🇸🇱 +232</option><option value="+378">SM 🇸🇲 +378</option><option value="+221">SN 🇸🇳 +221</option><option value="+252">SO 🇸🇴 +252</option><option value="+597">SR 🇸🇷 +597</option><option value="+211">SS 🇸🇸 +211</option><option value="+239">ST 🇸🇹 +239</option><option value="+503">SV 🇸🇻 +503</option><option value="+963">SY 🇸🇾 +963</option><option value="+235">TD 🇹🇩 +235</option><option value="+228">TG 🇹🇬 +228</option><option value="+66">TH 🇹🇭 +66</option><option value="+992">TJ 🇹🇯 +992</option><option value="+690">TK 🇹🇰 +690</option><option value="+670">TL 🇹🇱 +670</option><option value="+993">TM 🇹🇲 +993</option><option value="+216">TN 🇹🇳 +216</option><option value="+676">TO 🇹🇴 +676</option><option value="+90">TR 🇹🇷 +90</option><option value="+1">TT 🇹🇹 +1</option><option value="+688">TV 🇹🇻 +688</option><option value="+886">TW 🇹🇼 +886</option><option value="+255">TZ 🇹🇿 +255</option><option value="+380">UA 🇺🇦 +380</option><option value="+256">UG 🇺🇬 +256</option><option value="+1">US 🇺🇸 +1</option><option value="+598">UY 🇺🇾 +598</option><option value="+998">UZ 🇺🇿 +998</option><option value="+379">VA 🇻🇦 +379</option><option value="+1">VC 🇻🇨 +1</option><option value="+58">VE 🇻🇪 +58</option><option value="+84">VN 🇻🇳 +84</option><option value="+678">VU 🇻🇺 +678</option><option value="+681">WF 🇼🇫 +681</option><option value="+685">WS 🇼🇸 +685</option><option value="+383">XK 🇽🇰 +383</option><option value="+967">YE 🇾🇪 +967</option><option value="+262">YT 🇾🇹 +262</option><option value="+27">ZA 🇿🇦 +27</option><option value="+260">ZM 🇿🇲 +260</option><option value="+263">ZW 🇿🇼 +263</option>';
        if ( $country_code !== '+39' ) {
            $options = str_replace( 'value="+39" selected', 'value="+39"', $options );
            $options = str_replace( 'value="' . esc_attr( $country_code ) . '"', 'value="' . esc_attr( $country_code ) . '" selected', $options );
        }
        echo wp_kses( $options, [ 'option' => [ 'value' => [], 'selected' => [] ] ] );
        echo '</select>';
        printf( '<input required type="tel" id="otp-access-phone" name="otp_access_phone" autocomplete="tel" value="%s" style="flex:1;" placeholder="123456789" />', esc_attr( $phone_number ) );
        echo '</div>';
        echo '</div>';
        echo '<div><button type="submit" class="button button-primary">' . esc_html__( 'Invia codice OTP', 'otp-in' ) . '</button></div>';
        echo '</form>';
    }

    /**
     * Render OTP verification form.
     */
    public function render_verify_form( $post_id ) {
        $context = $this->get_view_context( $post_id );
        $first_name = $context['first_name'];
        $last_name  = $context['last_name'];
        $phone      = $context['phone'];

        // Usa i valori separati dal context
        $country_code = $context['country_code'];
        $phone_number = $context['phone_number'];
        
        echo '<form method="post" class="otp-access-form otp-access-verify">';
        wp_nonce_field( 'otp_access_verify_' . $post_id, 'otp_access_nonce' );
        echo '<input type="hidden" name="otp_access_action" value="verify" />';
        printf( '<input type="hidden" name="otp_access_first_name" value="%s" />', esc_attr( $first_name ) );
        printf( '<input type="hidden" name="otp_access_last_name" value="%s" />', esc_attr( $last_name ) );
        printf( '<input type="hidden" name="otp_access_country_code" value="%s" />', esc_attr( $country_code ) );
        printf( '<input type="hidden" name="otp_access_phone" value="%s" />', esc_attr( $phone_number ) );
        if ( $first_name || $last_name ) {
            printf(
                '<p class="otp-access-helper">%s</p>',
                sprintf(
                    /* translators: %s: User full name */
                    esc_html__( 'Codice inviato a: %s', 'otp-in' ),
                    esc_html( trim( $first_name . ' ' . $last_name ) )
                )
            );
        }
        echo '<div class="otp-access-field">';
        echo '<label for="otp-access-code">' . esc_html__( 'Inserisci il codice ricevuto', 'otp-in' ) . '</label>';
        echo '<input required pattern="[0-9]{6}" maxlength="6" type="text" id="otp-access-code" name="otp_access_code" />';
        echo '</div>';
        echo '<div><button type="submit" class="button button-primary">' . esc_html__( 'Verifica codice', 'otp-in' ) . '</button></div>';
        echo '</form>';
    }

    /**
     * Get all OTP user posts.
     */
    protected function get_all_otp_users() {
        return get_posts([
            'post_type'      => self::POST_TYPE_USER,
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'orderby'        => 'title',
            'order'          => 'ASC',
        ]);
    }

    /**
     * Find allowed user by submitted identity.
     */
    protected function find_allowed_user_by_identity( $post_id, $first_name, $last_name, $phone ) {
        $normalized_phone = $this->normalize_phone( $phone );
        $require_first_name = $this->get_option( self::OPTION_REQUIRE_FIRST_NAME );
        $require_last_name = $this->get_option( self::OPTION_REQUIRE_LAST_NAME );

        if ( '' === $normalized_phone ) {
            return null;
        }

        $allowed_ids = (array) get_post_meta( $post_id, self::META_ALLOWED_USERS, true );
        if ( empty( $allowed_ids ) ) {
            return null;
        }

        $users = get_posts( [
            'post_type'      => self::POST_TYPE_USER,
            'posts_per_page' => -1,
            'post__in'       => array_map( 'intval', $allowed_ids ),
            'post_status'    => 'publish',
        ] );

        foreach ( $users as $user_post ) {
            $stored_country_code = get_post_meta( $user_post->ID, self::META_COUNTRY_CODE, true );
            $stored_phone_number = get_post_meta( $user_post->ID, self::META_PHONE, true );
            
            // Se non ha country code separato, prova il vecchio formato
            if ( ! $stored_country_code ) {
                $old_phone = get_post_meta( $user_post->ID, self::META_PHONE, true );
                if ( preg_match( '/^(\+\d{1,4})(.+)$/', $old_phone, $matches ) ) {
                    $stored_country_code = $matches[1];
                    $stored_phone_number = $matches[2];
                } else {
                    $stored_country_code = '+39';
                    $stored_phone_number = $old_phone;
                }
            }
            
            $stored_full_phone = $this->normalize_phone( $stored_country_code . $stored_phone_number );
            
            if ( $normalized_phone !== $stored_full_phone ) {
                continue;
            }
            
            // Se nome richiesto, deve corrispondere
            if ( $require_first_name && $first_name ) {
                $stored_first = $this->normalize_name( get_post_meta( $user_post->ID, self::META_FIRST_NAME, true ) );
                if ( $this->normalize_name( $first_name ) !== $stored_first ) {
                    continue;
                }
            }
            
            // Se cognome richiesto, deve corrispondere
            if ( $require_last_name && $last_name ) {
                $stored_last = $this->normalize_name( get_post_meta( $user_post->ID, self::META_LAST_NAME, true ) );
                if ( $this->normalize_name( $last_name ) !== $stored_last ) {
                    continue;
                }
            }
            
            return $user_post;
        }

        return null;
    }

    /**
     * Output notice based on status.
     */
    public function render_status_notice( $post_id ) {
        $context = $this->get_view_context( $post_id );
        $status  = $context['status'];

        if ( ! $status ) {
            return;
        }

        $messages = [
            'code_sent'       => __( 'Codice inviato! Controlla la casella di posta.', 'otp-in' ),
            'invalid_code'    => __( 'Codice non valido o scaduto. Riprova.', 'otp-in' ),
            'user_not_allowed'=> __( 'Accesso non autorizzato. Riprova.', 'otp-in' ),
            'access_granted'  => __( 'Accesso concesso. Puoi visualizzare la pagina.', 'otp-in' ),
            'access_expired'  => __( 'Accesso scaduto.', 'otp-in' ),
            'access_disabled' => __( 'Accesso disabilitato.', 'otp-in' ),
        ];

        if ( isset( $messages[ $status ] ) ) {
            printf( '<div class="otp-access-notice otp-access-%1$s">%2$s</div>', esc_attr( $status ), esc_html( $messages[ $status ] ) );
        }
    }

    /**
     * Normalize name for comparisons.
     *
     * @param string $value
     * @return string
     */
    protected function normalize_name( $value ) {
        $value = trim( preg_replace( '/\s+/', ' ', (string) $value ) );

        if ( '' === $value ) {
            return '';
        }

        if ( function_exists( 'mb_strtolower' ) ) {
            return mb_strtolower( $value, 'UTF-8' );
        }

        return strtolower( $value );
    }

    /**
     * Set default title for new OTP users.
     */
    public function set_default_user_title( $title, $post ) {
        if ( self::POST_TYPE_USER === $post->post_type ) {
            /* translators: %d: Random user number */
            return sprintf( __( 'Utente n. %d', 'otp-in' ), wp_rand( 1000, 9999 ) );
        }
        return $title;
    }

    /**
     * Normalize phone number for comparisons.
     *
     * @param string $value
     * @return string
     */
    protected function normalize_phone( $value ) {
        $digits = preg_replace( '/\D+/', '', (string) $value );

        return $digits ?: '';
    }

    /**
     * Register plugin settings.
     */
    public function register_settings() {
        register_setting( 'otp_access_options', self::OPTION_BLOCKED_MESSAGE, [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_textarea_field',
            'default'           => __( 'Questo contenuto è protetto e non è accessibile.', 'otp-in' ),
        ] );
        
        register_setting( 'otp_access_options', self::OPTION_MODAL_TITLE, [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => __( 'Accesso tramite OTP', 'otp-in' ),
        ] );
        
        register_setting( 'otp_access_options', self::OPTION_REQUIRE_LAST_NAME, [
            'type'              => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default'           => true,
        ] );
        
        register_setting( 'otp_access_options', self::OPTION_REQUIRE_FIRST_NAME, [
            'type'              => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default'           => true,
        ] );
        
        register_setting( 'otp_access_options', self::OPTION_OVERLAY_COLOR, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_color' ],
            'default'           => '#f1f5f9',
        ] );
        
        register_setting( 'otp_access_options', self::OPTION_OVERLAY_OPACITY, [
            'type'              => 'number',
            'sanitize_callback' => [ $this, 'sanitize_opacity' ],
            'default'           => 1,
        ] );
        
        register_setting( 'otp_access_options', self::OPTION_MODAL_BG_COLOR, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_color' ],
            'default'           => '#ffffff',
        ] );
        
        register_setting( 'otp_access_options', self::OPTION_MODAL_TEXT_COLOR, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_color' ],
            'default'           => '#000000',
        ] );
        
        register_setting( 'otp_access_options', self::OPTION_MODAL_SHADOW, [
            'type'              => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default'           => true,
        ] );
    }

    /**
     * Sanitize opacity value.
     */
    public function sanitize_opacity( $value ) {
        $value = floatval( $value );
        return max( 0, min( 1, $value ) );
    }

    /**
     * Sanitize color value.
     */
    public function sanitize_color( $value ) {
        if ( preg_match( '/^#[a-f0-9]{6}$/i', $value ) ) {
            return $value;
        }
        return '#ffffff';
    }

    /**
     * Render options page.
     */
    public function render_options_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( isset( $_POST['otp_access_reset'] ) && check_admin_referer( 'otp_access_reset_options' ) ) {
            delete_option( self::OPTION_MODAL_TITLE );
            delete_option( self::OPTION_BLOCKED_MESSAGE );
            delete_option( self::OPTION_REQUIRE_FIRST_NAME );
            delete_option( self::OPTION_REQUIRE_LAST_NAME );
            add_settings_error( 'otp_access_messages', 'otp_access_message', __( 'Impostazioni ripristinate ai valori predefiniti', 'otp-in' ), 'updated' );
        }

        if ( isset( $_GET['settings-updated'] ) ) {
            add_settings_error( 'otp_access_messages', 'otp_access_message', __( 'Impostazioni salvate', 'otp-in' ), 'updated' );
        }

        settings_errors( 'otp_access_messages' );

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__( 'Opzioni', 'otp-in' ) . '</h1>';
        echo '<form method="post" action="options.php">';
        settings_fields( 'otp_access_options' );
        echo '<table class="form-table">';
        echo '<tr><th scope="row">' . esc_html__( 'Campo Nome', 'otp-in' ) . '</th>';
        echo '<td><label><input type="checkbox" id="' . esc_attr( self::OPTION_REQUIRE_FIRST_NAME ) . '" name="' . esc_attr( self::OPTION_REQUIRE_FIRST_NAME ) . '" value="1"' . checked( $this->get_option( self::OPTION_REQUIRE_FIRST_NAME ), true, false ) . ' /> ' . esc_html__( 'Richiedi campo Nome', 'otp-in' ) . '</label>';
        echo '<p class="description">' . esc_html__( 'Se disabilitato, il campo Nome non sarà visualizzato nel form.', 'otp-in' ) . '</p></td></tr>';
        echo '<tr><th scope="row">' . esc_html__( 'Campo Cognome', 'otp-in' ) . '</th>';
        echo '<td><label><input type="checkbox" id="' . esc_attr( self::OPTION_REQUIRE_LAST_NAME ) . '" name="' . esc_attr( self::OPTION_REQUIRE_LAST_NAME ) . '" value="1"' . checked( $this->get_option( self::OPTION_REQUIRE_LAST_NAME ), true, false ) . ' /> ' . esc_html__( 'Richiedi campo Cognome', 'otp-in' ) . '</label>';
        echo '<p class="description">' . esc_html__( 'Se disabilitato, il campo Cognome non sarà visualizzato nel form.', 'otp-in' ) . '</p></td></tr>';
        echo '<tr><th scope="row"><label for="' . esc_attr( self::OPTION_MODAL_TITLE ) . '">' . esc_html__( 'Titolo modale', 'otp-in' ) . '</label></th>';
        echo '<td><input type="text" id="' . esc_attr( self::OPTION_MODAL_TITLE ) . '" name="' . esc_attr( self::OPTION_MODAL_TITLE ) . '" value="' . esc_attr( $this->get_option( self::OPTION_MODAL_TITLE ) ) . '" class="regular-text" />';
        echo '<p class="description">' . esc_html__( 'Titolo della finestra di accesso OTP.', 'otp-in' ) . '</p></td></tr>';
        echo '<tr><th scope="row"><label for="' . esc_attr( self::OPTION_BLOCKED_MESSAGE ) . '">' . esc_html__( 'Messaggio contenuto bloccato', 'otp-in' ) . '</label></th>';
        echo '<td><textarea id="' . esc_attr( self::OPTION_BLOCKED_MESSAGE ) . '" name="' . esc_attr( self::OPTION_BLOCKED_MESSAGE ) . '" rows="3" class="large-text">' . esc_textarea( $this->get_option( self::OPTION_BLOCKED_MESSAGE ) ) . '</textarea>';
        echo '<p class="description">' . esc_html__( 'Messaggio mostrato quando il contenuto è protetto senza utenti autorizzati.', 'otp-in' ) . '</p></td></tr>';
        echo '</table><hr style="margin:30px 0;border:0;border-top:1px solid #ddd;"><h2>' . esc_html__( 'Personalizzazione modale', 'otp-in' ) . '</h2><table class="form-table">';
        echo '<tr><th scope="row"><label for="' . esc_attr( self::OPTION_OVERLAY_COLOR ) . '">' . esc_html__( 'Colore overlay', 'otp-in' ) . '</label></th>';
        echo '<td><input type="color" id="' . esc_attr( self::OPTION_OVERLAY_COLOR ) . '" name="' . esc_attr( self::OPTION_OVERLAY_COLOR ) . '" value="' . esc_attr( $this->get_option( self::OPTION_OVERLAY_COLOR ) ) . '" /> <button type="button" class="button" onclick="document.getElementById(\'' . esc_js( self::OPTION_OVERLAY_COLOR ) . '\').value=\'#f1f5f9\'">' . esc_html__( 'Reset', 'otp-in' ) . '</button>';
        echo '<p class="description">' . esc_html__( 'Colore di sfondo dell\'overlay della modale.', 'otp-in' ) . '</p></td></tr>';
        echo '<tr><th scope="row"><label for="' . esc_attr( self::OPTION_OVERLAY_OPACITY ) . '">' . esc_html__( 'Opacità overlay', 'otp-in' ) . '</label></th>';
        echo '<td><input type="number" id="' . esc_attr( self::OPTION_OVERLAY_OPACITY ) . '" name="' . esc_attr( self::OPTION_OVERLAY_OPACITY ) . '" value="' . esc_attr( $this->get_option( self::OPTION_OVERLAY_OPACITY ) ) . '" min="0" max="1" step="0.1" style="width:80px;" /> <button type="button" class="button" onclick="document.getElementById(\'' . esc_js( self::OPTION_OVERLAY_OPACITY ) . '\').value=\'1\'">' . esc_html__( 'Reset', 'otp-in' ) . '</button>';
        echo '<p class="description">' . esc_html__( 'Opacità dell\'overlay (da 0 a 1).', 'otp-in' ) . '</p></td></tr>';
        echo '<tr><th scope="row"><label for="' . esc_attr( self::OPTION_MODAL_BG_COLOR ) . '">' . esc_html__( 'Colore sfondo modale', 'otp-in' ) . '</label></th>';
        echo '<td><input type="color" id="' . esc_attr( self::OPTION_MODAL_BG_COLOR ) . '" name="' . esc_attr( self::OPTION_MODAL_BG_COLOR ) . '" value="' . esc_attr( $this->get_option( self::OPTION_MODAL_BG_COLOR ) ) . '" /> <button type="button" class="button" onclick="document.getElementById(\'' . esc_js( self::OPTION_MODAL_BG_COLOR ) . '\').value=\'#ffffff\'">' . esc_html__( 'Reset', 'otp-in' ) . '</button>';
        echo '<p class="description">' . esc_html__( 'Colore di sfondo del contenuto della modale.', 'otp-in' ) . '</p></td></tr>';
        echo '<tr><th scope="row"><label for="' . esc_attr( self::OPTION_MODAL_TEXT_COLOR ) . '">' . esc_html__( 'Colore testo modale', 'otp-in' ) . '</label></th>';
        echo '<td><input type="color" id="' . esc_attr( self::OPTION_MODAL_TEXT_COLOR ) . '" name="' . esc_attr( self::OPTION_MODAL_TEXT_COLOR ) . '" value="' . esc_attr( $this->get_option( self::OPTION_MODAL_TEXT_COLOR ) ) . '" /> <button type="button" class="button" onclick="document.getElementById(\'' . esc_js( self::OPTION_MODAL_TEXT_COLOR ) . '\').value=\'#000000\'">' . esc_html__( 'Reset', 'otp-in' ) . '</button>';
        echo '<p class="description">' . esc_html__( 'Colore del testo all\'interno della modale.', 'otp-in' ) . '</p></td></tr>';
        echo '<tr><th scope="row">' . esc_html__( 'Ombra modale', 'otp-in' ) . '</th>';
        echo '<td><label><input type="checkbox" id="' . esc_attr( self::OPTION_MODAL_SHADOW ) . '" name="' . esc_attr( self::OPTION_MODAL_SHADOW ) . '" value="1"' . checked( $this->get_option( self::OPTION_MODAL_SHADOW ), true, false ) . ' /> ' . esc_html__( 'Mostra ombra della modale', 'otp-in' ) . '</label></td></tr>';
        echo '</table>';
        submit_button();
        echo '</form>';
        echo '<form method="post" style="margin-top:20px;">';
        wp_nonce_field( 'otp_access_reset_options' );
        echo '<input type="hidden" name="otp_access_reset" value="1" />';
        submit_button( __( 'Ripristina valori predefiniti', 'otp-in' ), 'secondary', 'submit', false );
        echo '</form></div>';
    }

    /**
     * Get option value with default fallback.
     */
    public function get_option( $option_name ) {
        $defaults = [
            self::OPTION_BLOCKED_MESSAGE => __( 'Questo contenuto è protetto e non è accessibile.', 'otp-in' ),
            self::OPTION_MODAL_TITLE => __( 'Accesso tramite OTP', 'otp-in' ),
            self::OPTION_REQUIRE_FIRST_NAME => true,
            self::OPTION_REQUIRE_LAST_NAME => true,
            self::OPTION_OVERLAY_COLOR => '#f1f5f9',
            self::OPTION_OVERLAY_OPACITY => 1,
            self::OPTION_MODAL_BG_COLOR => '#ffffff',
            self::OPTION_MODAL_TEXT_COLOR => '#000000',
            self::OPTION_MODAL_SHADOW => true,
        ];
        
        $value = get_option( $option_name );
        
        if ( false === $value && isset( $defaults[ $option_name ] ) ) {
            return $defaults[ $option_name ];
        }
        
        return $value;
    }

    /**
     * Output custom modal styles.
     */
    public function output_custom_modal_styles() {
        if ( ! is_singular() ) {
            return;
        }
        
        $post_id = get_queried_object_id();
        if ( ! $post_id || ! $this->is_post_protected( $post_id ) ) {
            return;
        }
        
        $overlay_color = $this->get_option( self::OPTION_OVERLAY_COLOR );
        $overlay_opacity = $this->get_option( self::OPTION_OVERLAY_OPACITY );
        $modal_bg = $this->get_option( self::OPTION_MODAL_BG_COLOR );
        $modal_text = $this->get_option( self::OPTION_MODAL_TEXT_COLOR );
        $modal_shadow = $this->get_option( self::OPTION_MODAL_SHADOW );
        
        $r = hexdec( substr( $overlay_color, 1, 2 ) );
        $g = hexdec( substr( $overlay_color, 3, 2 ) );
        $b = hexdec( substr( $overlay_color, 5, 2 ) );
        
        $shadow = $modal_shadow ? '0 25px 60px -25px rgba(15, 23, 42, 0.55)' : 'none';
        
        echo '<style>.otp-access-overlay{background:rgba(' . esc_attr( $r ) . ',' . esc_attr( $g ) . ',' . esc_attr( $b ) . ',' . esc_attr( $overlay_opacity ) . ') !important;}.otp-access-modal{background:' . esc_attr( $modal_bg ) . ' !important;color:' . esc_attr( $modal_text ) . ' !important;box-shadow:' . esc_attr( $shadow ) . ' !important;}.otp-access-modal-title,.otp-access-modal-lead,.otp-access-field label{color:' . esc_attr( $modal_text ) . ' !important;}</style>';
    }
}
