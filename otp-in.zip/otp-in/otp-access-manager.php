<?php
/**
 * Plugin Name: 🛡️ OTP in
 * Description: 🔒 Easily protect any page or post with the integrated OTP system and manage all authorized users from a single, simple and intuitive centralized section. Access is granted by entering first name, last name and phone number, allowing you to quickly and securely receive the verification code directly via email.
 * Version: 1.0.0
 * Author: Marco Gargano
 * Author URI: https://www.marcogargano.com
 * Text Domain: otp-in
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'OTP_ACCESS_MANAGER_PATH', plugin_dir_path( __FILE__ ) );
define( 'OTP_ACCESS_MANAGER_URL', plugin_dir_url( __FILE__ ) );
require_once OTP_ACCESS_MANAGER_PATH . 'includes/class-otp-access-plugin.php';

function otp_access_manager_bootstrap() {
    return OTP_Access_Manager_Plugin::instance();
}

add_action( 'plugins_loaded', 'otp_access_manager_bootstrap' );

function otp_access_manager_activate() {
    otp_access_manager_bootstrap();
    flush_rewrite_rules();
}

function otp_access_manager_deactivate() {
    flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'otp_access_manager_activate' );
register_deactivation_hook( __FILE__, 'otp_access_manager_deactivate' );
