=== 🛡️ OTP in – Secure OTP Access for WordPress ===
Contributors: marcogargano
Tags: otp, authentication, security, access-control, email, passwordless
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Protect any WordPress page or post with temporary OTP codes sent via email. Passwordless access, user management, modal customization, and full monitoring of protected content.

== Description ==

OTP in is a WordPress plugin that protects pages and posts using email-delivered One-Time Passwords. Each authorized user receives a time-limited OTP valid for 15 minutes, allowing secure access without passwords.

The plugin includes full user management, modal customization, protected content tracking, and secure cookies to maintain the login session.

== Features ==

= 🔐 Advanced Security =
* Passwordless access via email OTP
* 3-factor authentication (first name, last name, phone)
* OTP codes expire after 15 minutes
* Secure access tokens via cookies

= 🎨 Fully Customizable =
* Custom modal colors (overlay, background, text)
* Adjustable opacity and shadow
* Custom titles and messages
* Professional HTML email templates

= 👥 User Management =
* Create OTP users with name, email, and phone
* Enable/disable users instantly
* Custom access duration
* Optional expiration date and time
* User status indicator

= 🔒 Content Protection =
* Enable OTP protection per page/post
* Assign authorized users
* Multi-select feature
* Protection status column

= 📊 Monitoring =
* View all protected pages/posts
* See authorized users
* Direct quick-edit access

= ⚙️ Flexible Configuration =
* Optional last name field
* Custom blocked-content messages
* Reset all settings to default

== Installation ==

1. Upload the `otp-access-manager` folder to `/wp-content/plugins/`
2. Activate the plugin from the “Plugins” menu
3. Go to “OTP in” in your admin menu

== Screenshots ==

1. OTP users dashboard
2. OTP login modal
3. Customization options
4. Content protection sidebar
5. HTML email template
6. Protected content list

== Changelog ==

= 1.0.0 =
Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial stable version.

== Frequently Asked Questions ==

= Does the plugin require SMTP? =
No, but SMTP is recommended for reliable email delivery.

= Can I protect only specific pages? =
Yes, protection is applied per page/post.

= How long does the OTP last? =
15 minutes.
